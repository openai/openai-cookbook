# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["VectorStoreSearchResponse", "Content"]


class Content(BaseModel):
    text: str
    """The text content returned from search."""

    type: Literal["text"]
    """The type of content."""


class VectorStoreSearchResponse(BaseModel):
    attributes: Dict[str, Union[str, float, bool]]
    """Optional user-defined attributes."""

    content: List[Content]
    """Content chunks from the file."""

    file_id: str
    """The ID of the vector store file."""

    filename: str
    """The name of the vector store file."""

    score: float
    """The similarity score for the result."""
