# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from pydantic import Field as FieldInfo

from .._utils import PropertyInfo
from .._models import BaseModel
from .shared.metadata import Metadata
from .completion_usage import CompletionUsage
from .shared.response_format_text import ResponseFormatText
from .shared.response_format_json_object import ResponseFormatJSONObject
from .chat.chat_completion_reasoning_effort import ChatCompletionReasoningEffort

__all__ = [
    "Response",
    "Error",
    "Output",
    "OutputOutputMessage",
    "OutputOutputMessageContent",
    "OutputOutputMessageContentOutputText",
    "OutputOutputMessageContentOutputTextAnnotation",
    "OutputOutputMessageContentOutputTextAnnotationFileCitation",
    "OutputOutputMessageContentOutputTextAnnotationURLCitation",
    "OutputOutputMessageContentOutputTextAnnotationFilePath",
    "OutputOutputMessageContentOutputTextLogprob",
    "OutputOutputMessageContentOutputTextLogprobTopLogprob",
    "OutputOutputMessageContentRefusal",
    "OutputOutputMessageContentOutputAudio",
    "OutputFileSearchToolCall",
    "OutputFileSearchToolCallResult",
    "OutputFileSearchToolCallResultContent",
    "OutputFileSearchToolCallResultContentInputText",
    "OutputFileSearchToolCallResultContentInputAudio",
    "OutputFileSearchToolCallResultContentInputImage",
    "OutputFileSearchToolCallResultContentInputFile",
    "OutputFileSearchToolCallResultContentOutputText",
    "OutputFileSearchToolCallResultContentOutputTextAnnotation",
    "OutputFileSearchToolCallResultContentOutputTextAnnotationFileCitation",
    "OutputFileSearchToolCallResultContentOutputTextAnnotationURLCitation",
    "OutputFileSearchToolCallResultContentOutputTextAnnotationFilePath",
    "OutputFileSearchToolCallResultContentOutputTextLogprob",
    "OutputFileSearchToolCallResultContentOutputTextLogprobTopLogprob",
    "OutputFileSearchToolCallResultContentRefusal",
    "OutputFileSearchToolCallResultContentOutputAudio",
    "OutputFunctionToolCall",
    "OutputWebSearchToolCall",
    "OutputComputerToolCall",
    "OutputComputerToolCallAction",
    "OutputComputerToolCallActionClick",
    "OutputComputerToolCallActionDoubleClick",
    "OutputComputerToolCallActionDrag",
    "OutputComputerToolCallActionDragPath",
    "OutputComputerToolCallActionKeypress",
    "OutputComputerToolCallActionMove",
    "OutputComputerToolCallActionScreenshot",
    "OutputComputerToolCallActionScroll",
    "OutputComputerToolCallActionType",
    "OutputComputerToolCallActionWait",
    "ToolChoice",
    "ToolChoiceToolChoiceTypes",
    "ToolChoiceToolChoiceFunction",
    "Tool",
    "ToolFileSearch",
    "ToolFunction",
    "ToolComputerPreview",
    "ToolWebSearch",
    "ToolWebSearchLocation",
    "Text",
    "TextFormat",
    "TextFormatJSONSchema",
]


class Error(BaseModel):
    code: Literal[
        "server_error",
        "rate_limit_exceeded",
        "invalid_prompt",
        "vector_store_timeout",
        "invalid_image",
        "invalid_image_format",
        "invalid_base64_image",
        "invalid_image_url",
        "image_too_large",
        "image_too_small",
        "image_parse_error",
        "image_content_policy_violation",
        "invalid_image_mode",
        "image_file_too_large",
        "unsupported_image_media_type",
        "empty_image_file",
        "failed_to_download_image",
        "image_file_not_found",
    ]
    """The error code for the response."""

    message: str
    """A human-readable description of the error."""


class OutputOutputMessageContentOutputTextAnnotationFileCitation(BaseModel):
    file_id: str
    """The ID of the file."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_citation"]
    """The type of the file citation. Always `file_citation`."""


class OutputOutputMessageContentOutputTextAnnotationURLCitation(BaseModel):
    index: float
    """The character index where the URL is used in the response."""

    title: str
    """The title of the web resource."""

    type: Literal["url_citation"]
    """The type of the URL citation. Always `url_citation`."""

    url: str
    """The URL of the web resource."""


class OutputOutputMessageContentOutputTextAnnotationFilePath(BaseModel):
    file_id: str
    """The ID of the file."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_path"]
    """The type of the file path. Always `file_path`."""


OutputOutputMessageContentOutputTextAnnotation: TypeAlias = Annotated[
    Union[
        OutputOutputMessageContentOutputTextAnnotationFileCitation,
        OutputOutputMessageContentOutputTextAnnotationURLCitation,
        OutputOutputMessageContentOutputTextAnnotationFilePath,
    ],
    PropertyInfo(discriminator="type"),
]


class OutputOutputMessageContentOutputTextLogprobTopLogprob(BaseModel):
    token: str
    """The token that was used to generate the log probability."""

    bytes: List[int]
    """The bytes that were used to generate the log probability."""

    logprob: float
    """The log probability of the token."""


class OutputOutputMessageContentOutputTextLogprob(BaseModel):
    token: str
    """The token that was used to generate the log probability."""

    bytes: List[int]
    """The bytes that were used to generate the log probability."""

    logprob: float
    """The log probability of the token."""

    top_logprobs: Optional[List[OutputOutputMessageContentOutputTextLogprobTopLogprob]] = None


class OutputOutputMessageContentOutputText(BaseModel):
    annotations: List[OutputOutputMessageContentOutputTextAnnotation]
    """The annotations of the text output."""

    text: str
    """The text output from the model."""

    type: Literal["output_text"]
    """The type of the output text. Always `output_text`."""

    logprobs: Optional[List[OutputOutputMessageContentOutputTextLogprob]] = None
    """The log probabilities of the tokens in the text output."""


class OutputOutputMessageContentRefusal(BaseModel):
    refusal: str
    """The refusal explanationfrom the model."""

    type: Literal["refusal"]
    """The type of the refusal. Always `refusal`."""


class OutputOutputMessageContentOutputAudio(BaseModel):
    data: str
    """Base64-encoded audio data from the model."""

    transcript: str
    """The transcript of the audio data from the model."""

    type: Literal["output_audio"]
    """The type of the output audio. Always `output_audio`."""


OutputOutputMessageContent: TypeAlias = Annotated[
    Union[
        OutputOutputMessageContentOutputText, OutputOutputMessageContentRefusal, OutputOutputMessageContentOutputAudio
    ],
    PropertyInfo(discriminator="type"),
]


class OutputOutputMessage(BaseModel):
    id: str
    """The unique ID of the output message."""

    content: List[OutputOutputMessageContent]
    """The content of the output message."""

    role: Literal["assistant"]
    """The role of the output message. Always `assistant`."""

    type: Literal["message"]
    """The type of the output message. Always `message`."""


class OutputFileSearchToolCallResultContentInputText(BaseModel):
    text: str
    """The text input to the model."""

    type: Literal["input_text"]
    """The type of the input item. Always `input_text`."""


class OutputFileSearchToolCallResultContentInputAudio(BaseModel):
    data: str
    """Base64-encoded audio data."""

    format: Literal["mp3", "wav"]
    """The format of the audio data. Currently supported formats are `mp3` and `wav`."""

    type: Literal["input_audio"]
    """The type of the input item. Always `input_audio`."""


class OutputFileSearchToolCallResultContentInputImage(BaseModel):
    detail: Literal["high", "low", "auto"]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`. Defaults to `auto`.
    """

    type: Literal["input_image"]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str] = None
    """The ID of the file to be sent to the model."""

    image_url: Optional[str] = None
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class OutputFileSearchToolCallResultContentInputFile(BaseModel):
    type: Literal["input_file"]
    """The type of the input item. Always `input_file`."""

    file_data: Optional[str] = None
    """The content of the file to be sent to the model."""

    file_id: Optional[str] = None
    """The ID of the file to be sent to the model."""

    file_name: Optional[str] = None
    """The name of the file to be sent to the model."""


class OutputFileSearchToolCallResultContentOutputTextAnnotationFileCitation(BaseModel):
    file_id: str
    """The ID of the file."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_citation"]
    """The type of the file citation. Always `file_citation`."""


class OutputFileSearchToolCallResultContentOutputTextAnnotationURLCitation(BaseModel):
    index: float
    """The character index where the URL is used in the response."""

    title: str
    """The title of the web resource."""

    type: Literal["url_citation"]
    """The type of the URL citation. Always `url_citation`."""

    url: str
    """The URL of the web resource."""


class OutputFileSearchToolCallResultContentOutputTextAnnotationFilePath(BaseModel):
    file_id: str
    """The ID of the file."""

    index: int
    """The index of the file in the list of files."""

    type: Literal["file_path"]
    """The type of the file path. Always `file_path`."""


OutputFileSearchToolCallResultContentOutputTextAnnotation: TypeAlias = Annotated[
    Union[
        OutputFileSearchToolCallResultContentOutputTextAnnotationFileCitation,
        OutputFileSearchToolCallResultContentOutputTextAnnotationURLCitation,
        OutputFileSearchToolCallResultContentOutputTextAnnotationFilePath,
    ],
    PropertyInfo(discriminator="type"),
]


class OutputFileSearchToolCallResultContentOutputTextLogprobTopLogprob(BaseModel):
    token: str
    """The token that was used to generate the log probability."""

    bytes: List[int]
    """The bytes that were used to generate the log probability."""

    logprob: float
    """The log probability of the token."""


class OutputFileSearchToolCallResultContentOutputTextLogprob(BaseModel):
    token: str
    """The token that was used to generate the log probability."""

    bytes: List[int]
    """The bytes that were used to generate the log probability."""

    logprob: float
    """The log probability of the token."""

    top_logprobs: Optional[List[OutputFileSearchToolCallResultContentOutputTextLogprobTopLogprob]] = None


class OutputFileSearchToolCallResultContentOutputText(BaseModel):
    annotations: List[OutputFileSearchToolCallResultContentOutputTextAnnotation]
    """The annotations of the text output."""

    text: str
    """The text output from the model."""

    type: Literal["output_text"]
    """The type of the output text. Always `output_text`."""

    logprobs: Optional[List[OutputFileSearchToolCallResultContentOutputTextLogprob]] = None
    """The log probabilities of the tokens in the text output."""


class OutputFileSearchToolCallResultContentRefusal(BaseModel):
    refusal: str
    """The refusal explanationfrom the model."""

    type: Literal["refusal"]
    """The type of the refusal. Always `refusal`."""


class OutputFileSearchToolCallResultContentOutputAudio(BaseModel):
    data: str
    """Base64-encoded audio data from the model."""

    transcript: str
    """The transcript of the audio data from the model."""

    type: Literal["output_audio"]
    """The type of the output audio. Always `output_audio`."""


OutputFileSearchToolCallResultContent: TypeAlias = Union[
    OutputFileSearchToolCallResultContentInputText,
    OutputFileSearchToolCallResultContentInputAudio,
    OutputFileSearchToolCallResultContentInputImage,
    OutputFileSearchToolCallResultContentInputFile,
    OutputFileSearchToolCallResultContentOutputText,
    OutputFileSearchToolCallResultContentRefusal,
    OutputFileSearchToolCallResultContentOutputAudio,
]


class OutputFileSearchToolCallResult(BaseModel):
    content: Optional[List[OutputFileSearchToolCallResultContent]] = None
    """The content returned from the file search tool call."""

    file_id: Optional[str] = None
    """The unique ID of the file."""

    file_name: Optional[str] = None
    """The name of the file."""

    score: Optional[float] = None
    """The relevance score of the file."""


class OutputFileSearchToolCall(BaseModel):
    id: str
    """The unique ID of the file search tool call."""

    queries: List[str]
    """The queries used to search for files."""

    status: Literal["in_progress", "searching", "completed"]
    """The status of the file search tool call."""

    type: Literal["file_search_call"]
    """The type of the file search tool call. Always `file_search_call`."""

    results: Optional[List[OutputFileSearchToolCallResult]] = None
    """The results of the file search tool call."""


class OutputFunctionToolCall(BaseModel):
    id: str
    """The unique ID of the function tool call."""

    arguments: str
    """A JSON string of the arguments to pass to the function."""

    name: str
    """The name of the function to run."""

    type: Literal["function_call"]
    """The type of the function tool call. Always `function_call`."""


class OutputWebSearchToolCall(BaseModel):
    id: str
    """The unique ID of the web search tool call."""

    status: Literal["in_progress", "completed"]
    """The status of the web search tool call."""

    type: Literal["web_search_call"]
    """The type of the web search tool call. Always `web_search_call`."""


class OutputComputerToolCallActionClick(BaseModel):
    button: Literal["left", "right", "wheel", "back", "forward"]
    """Indicates which mouse button was pressed during the click."""

    type: Literal["click"]
    """Specifies the event type.

    For a click action, this property is always set to "click".
    """

    x: float
    """The x-coordinate where the click occurred."""

    y: float
    """The y-coordinate where the click occurred."""


class OutputComputerToolCallActionDoubleClick(BaseModel):
    type: Literal["double_click"]
    """Specifies the event type.

    For a double click action, this property is always set to "double_click".
    """

    x: float
    """The x-coordinate where the double click occurred."""

    y: float
    """The y-coordinate where the double click occurred."""


class OutputComputerToolCallActionDragPath(BaseModel):
    x: float
    """The x-coordinate for a point in the drag path."""

    y: float
    """The y-coordinate for a point in the drag path."""


class OutputComputerToolCallActionDrag(BaseModel):
    path: List[OutputComputerToolCallActionDragPath]
    """An array of coordinates representing the path of the drag action."""

    type: Literal["drag"]
    """Specifies the event type.

    For a drag action, this property is always set to "drag".
    """


class OutputComputerToolCallActionKeypress(BaseModel):
    keys: List[str]
    """The combination of keys that were pressed during the keypress action."""

    type: Literal["keypress"]
    """Specifies the event type.

    For a keypress action, this property is always set to "keypress".
    """


class OutputComputerToolCallActionMove(BaseModel):
    type: Literal["move"]
    """Specifies the event type.

    For a move action, this property is always set to "move".
    """

    x: float
    """The x-coordinate to move to."""

    y: float
    """The y-coordinate to move to."""


class OutputComputerToolCallActionScreenshot(BaseModel):
    type: Literal["screenshot"]
    """Specifies the event type.

    For a screenshot action, this property is always set to "screenshot".
    """


class OutputComputerToolCallActionScroll(BaseModel):
    scroll_x: float
    """The horizontal scroll distance."""

    scroll_y: float
    """The vertical scroll distance."""

    type: Literal["scroll"]
    """Specifies the event type.

    For a scroll action, this property is always set to "scroll".
    """

    x: float
    """The x-coordinate where the scroll occurred."""

    y: float
    """The y-coordinate where the scroll occurred."""


class OutputComputerToolCallActionType(BaseModel):
    text: str
    """The text to type."""

    type: Literal["type"]
    """Specifies the event type.

    For a type action, this property is always set to "type".
    """


class OutputComputerToolCallActionWait(BaseModel):
    type: Literal["wait"]
    """Specifies the event type.

    For a wait action, this property is always set to "wait".
    """

    wait_milliseconds: float
    """The duration to wait, in milliseconds."""


OutputComputerToolCallAction: TypeAlias = Annotated[
    Union[
        OutputComputerToolCallActionClick,
        OutputComputerToolCallActionDoubleClick,
        OutputComputerToolCallActionDrag,
        OutputComputerToolCallActionKeypress,
        OutputComputerToolCallActionMove,
        OutputComputerToolCallActionScreenshot,
        OutputComputerToolCallActionScroll,
        OutputComputerToolCallActionType,
        OutputComputerToolCallActionWait,
    ],
    PropertyInfo(discriminator="type"),
]


class OutputComputerToolCall(BaseModel):
    id: str

    action: OutputComputerToolCallAction
    """A click action."""

    type: Literal["computer_call"]


Output: TypeAlias = Union[
    OutputOutputMessage,
    OutputFileSearchToolCall,
    OutputFunctionToolCall,
    OutputWebSearchToolCall,
    OutputComputerToolCall,
]


class ToolChoiceToolChoiceTypes(BaseModel):
    type: Literal["file_search", "web_search", "computer-preview"]
    """The type of hosted tool the model should to use.

    Learn more about [hosted tools](https://platform.openai.com/docs/guides/tools).

    Allowed values are:

    - `file_search`
    - `web_search`
    - `computer-preview`
    """


class ToolChoiceToolChoiceFunction(BaseModel):
    name: str
    """The name of the function to call."""

    type: Literal["function"]
    """For function calling, the type is always `function`."""


ToolChoice: TypeAlias = Union[
    Literal["none", "auto", "required"], ToolChoiceToolChoiceTypes, ToolChoiceToolChoiceFunction
]


class ToolFileSearch(BaseModel):
    max_num_results: int
    """The maximum number of results to return."""

    type: Literal["file_search"]
    """The type of the file search tool. Always `file_search`."""

    vector_store_ids: List[str]
    """The IDs of the vector stores to search."""


class ToolFunction(BaseModel):
    name: str
    """The name of the function to call."""

    parameters: Dict[str, object]
    """A JSON schema object describing the parameters of the function."""

    strict: bool
    """Whether to enforce strict parameter validation."""

    type: Literal["function"]
    """The type of the function tool. Always `function`."""

    description: Optional[str] = None
    """A description of the function.

    Used by the model to determine whether or not to call the function.
    """


class ToolComputerPreview(BaseModel):
    display_height: float
    """The height of the computer display."""

    display_width: float
    """The width of the computer display."""

    environment_type: Literal["mac", "windows", "ubuntu", "browser"]
    """The type of computer environment to control."""

    type: Literal["computer-preview"]
    """The type of the computer use tool. Always `computer-preview`."""


class ToolWebSearchLocation(BaseModel):
    time_zone: Optional[str] = None
    """The time zone of the user."""

    user_city: Optional[str] = None
    """The city of the user."""

    user_country: Optional[str] = None
    """The country of the user."""

    user_region: Optional[str] = None
    """The region of the user."""


class ToolWebSearch(BaseModel):
    type: Literal["web_search"]
    """The type of the web search tool. Always `web_search`."""

    location: Optional[ToolWebSearchLocation] = None
    """Optional location parameters for the search."""

    sites: Optional[List[str]] = None
    """An optional list of domains to constrain the search to. Examples:

    `["platform.openai.com", "developer.mozilla.org"]`
    """


Tool: TypeAlias = Annotated[
    Union[ToolFileSearch, ToolFunction, ToolComputerPreview, ToolWebSearch], PropertyInfo(discriminator="type")
]


class TextFormatJSONSchema(BaseModel):
    schema_: Dict[str, object] = FieldInfo(alias="schema")
    """
    The schema for the response format, described as a JSON Schema object. Learn how
    to build JSON schemas [here](https://json-schema.org/).
    """

    type: Literal["json_schema"]
    """The type of response format being defined. Always `json_schema`."""

    description: Optional[str] = None
    """
    A description of what the response format is for, used by the model to determine
    how to respond in the format.
    """

    name: Optional[str] = None
    """The name of the response format.

    Must be a-z, A-Z, 0-9, or contain underscores and dashes, with a maximum length
    of 64.
    """

    strict: Optional[bool] = None
    """
    Whether to enable strict schema adherence when generating the output. If set to
    true, the model will always follow the exact schema defined in the `schema`
    field. Only a subset of JSON Schema is supported when `strict` is `true`. To
    learn more, read the
    [Structured Outputs guide](https://platform.openai.com/docs/guides/structured-outputs).
    """


TextFormat: TypeAlias = Annotated[
    Union[ResponseFormatText, TextFormatJSONSchema, ResponseFormatJSONObject], PropertyInfo(discriminator="type")
]


class Text(BaseModel):
    format: Optional[TextFormat] = None
    """An object specifying the format that the model must output.

    Configuring `{ "type": "json_schema" }` enables Structured Outputs, which
    ensures the model will match your supplied JSON schema. Learn more in the
    [Structured Outputs guide](https://platform.openai.com/docs/guides/structured-outputs).

    The default format is `{ "type": "text" }` with no additional options.

    **Not recommended for gpt-4o and newer models:**

    Setting to `{ "type": "json_object" }` enables the older JSON mode, which
    ensures the message the model generates is valid JSON. Using `json_schema` is
    preferred for models that support it.
    """

    stop: Union[Optional[str], List[str], None] = None
    """Up to 4 sequences where the API will stop generating further tokens.

    The returned text will not contain the stop sequence.
    """


class Response(BaseModel):
    id: str
    """Unique identifier for this Response."""

    created_at: float
    """Unix timestamp (in seconds) of when this Response was created."""

    error: Optional[Error] = None
    """An error object returned when the model fails to generate a Response."""

    metadata: Optional[Metadata] = None
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.

    Keys are strings with a maximum length of 64 characters. Values are strings with
    a maximum length of 512 characters.
    """

    model: Union[
        str,
        Literal[
            "o3-mini",
            "o3-mini-2025-01-31",
            "o1",
            "o1-2024-12-17",
            "o1-preview",
            "o1-preview-2024-09-12",
            "o1-mini",
            "o1-mini-2024-09-12",
            "gpt-4o",
            "gpt-4o-2024-11-20",
            "gpt-4o-2024-08-06",
            "gpt-4o-2024-05-13",
            "gpt-4o-audio-preview",
            "gpt-4o-audio-preview-2024-10-01",
            "gpt-4o-audio-preview-2024-12-17",
            "gpt-4o-mini-audio-preview",
            "gpt-4o-mini-audio-preview-2024-12-17",
            "chatgpt-4o-latest",
            "gpt-4o-mini",
            "gpt-4o-mini-2024-07-18",
            "gpt-4-turbo",
            "gpt-4-turbo-2024-04-09",
            "gpt-4-0125-preview",
            "gpt-4-turbo-preview",
            "gpt-4-1106-preview",
            "gpt-4-vision-preview",
            "gpt-4",
            "gpt-4-0314",
            "gpt-4-0613",
            "gpt-4-32k",
            "gpt-4-32k-0314",
            "gpt-4-32k-0613",
            "gpt-3.5-turbo",
            "gpt-3.5-turbo-16k",
            "gpt-3.5-turbo-0301",
            "gpt-3.5-turbo-0613",
            "gpt-3.5-turbo-1106",
            "gpt-3.5-turbo-0125",
            "gpt-3.5-turbo-16k-0613",
        ],
    ]
    """Model ID used to generate the response, like `gpt-4o` or `o1`.

    OpenAI offers a wide range of models with different capabilities, performance
    characteristics, and price points. Refer to the
    [model guide](https://platform.openai.com/docs/models) to browse and compare
    available models.
    """

    object: Literal["response"]
    """The object type of this resource - always set to `response`."""

    output: List[Output]
    """An array of content items generated by the model."""

    temperature: Optional[float] = None
    """What sampling temperature to use, between 0 and 2.

    Higher values like 0.8 will make the output more random, while lower values like
    0.2 will make it more focused and deterministic. We generally recommend altering
    this or `top_p` but not both.
    """

    tool_choice: ToolChoice
    """
    How the model should select which tool (or tools) to use when generating a
    response. See the `tools` parameter to see how to specify which tools the model
    can call.
    """

    tools: Optional[List[Tool]] = None
    """An array of tools the model may call while generating a response.

    You can specify which tool to use by setting the `tool_choice` parameter.

    The two categories of tools you can provide the model are:

    - **Hosted tools**: Tools that are provided by OpenAI that extend the model's
      capabilities, like
      [web search](https://platform.openai.com/docs/guides/tools-web-search) or
      [file search](https://platform.openai.com/docs/guides/tools-file-search).
      Learn more about
      [hosted tools](https://platform.openai.com/docs/guides/tools).
    - **Function calls (custom tools)**: Functions that are defined by you, enabling
      the model to call your own code. Learn more about
      [function calling](https://platform.openai.com/docs/guides/function-calling).
    """

    top_p: Optional[float] = None
    """
    An alternative to sampling with temperature, called nucleus sampling, where the
    model considers the results of the tokens with top_p probability mass. So 0.1
    means only the tokens comprising the top 10% probability mass are considered.

    We generally recommend altering this or `temperature` but not both.
    """

    max_completion_tokens: Optional[int] = None
    """
    An upper bound for the number of tokens that can be generated for a completion,
    including visible output tokens and
    [reasoning tokens](https://platform.openai.com/docs/guides/reasoning).
    """

    previous_response_id: Optional[str] = None
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations. Learn more about
    [conversation state](https://platform.openai.com/docs/guides/conversation-state).
    """

    reasoning_effort: Optional[ChatCompletionReasoningEffort] = None
    """**o-series models only**

    Constrains effort on reasoning for
    [reasoning models](https://platform.openai.com/docs/guides/reasoning). Currently
    supported values are `low`, `medium`, and `high`. Reducing reasoning effort can
    result in faster responses and fewer tokens used on reasoning in a response.
    """

    text: Optional[Text] = None
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data. Learn more:

    - [Text inputs and outputs](https://platform.openai.com/docs/guides/text)
    - [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)
    """

    top_logprobs: Optional[int] = None
    """
    An integer between 0 and 20 specifying the number of most likely tokens to
    return at each token position, each with an associated log probability.
    `logprobs` must be set to `true` if this parameter is used.
    """

    truncation: Optional[Literal["auto", "disabled"]] = None
    """The truncation strategy to use for the model response.

    - `auto`: If the context of this response and previous ones exceeds the model's
      context window size, the model will truncate the response to fit the context
      window by dropping input items in the middle of the conversation.
    - `disabled` (default): If a model response will exceed the context window size
      for a model, the request will fail with a 400 error.
    """

    usage: Optional[CompletionUsage] = None
    """Usage statistics for the completion request."""
