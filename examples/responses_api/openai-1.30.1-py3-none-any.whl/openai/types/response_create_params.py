# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, List, Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from .shared_params.metadata import Metadata
from .shared_params.response_format_text import ResponseFormatText
from .chat.chat_completion_reasoning_effort import ChatCompletionReasoningEffort
from .shared_params.response_format_json_object import ResponseFormatJSONObject

__all__ = [
    "ResponseCreateParams",
    "InputInputItemList",
    "InputInputItemListEasyInputMessage",
    "InputInputItemListEasyInputMessageContentInputItemList",
    "InputInputItemListEasyInputMessageContentInputItemListInputText",
    "InputInputItemListEasyInputMessageContentInputItemListInputAudio",
    "InputInputItemListEasyInputMessageContentInputItemListInputImage",
    "InputInputItemListEasyInputMessageContentInputItemListInputFile",
    "InputInputItemListInputMessage",
    "InputInputItemListInputMessageContent",
    "InputInputItemListInputMessageContentInputText",
    "InputInputItemListInputMessageContentInputAudio",
    "InputInputItemListInputMessageContentInputImage",
    "InputInputItemListInputMessageContentInputFile",
    "InputInputItemListOutputMessage",
    "InputInputItemListOutputMessageContent",
    "InputInputItemListOutputMessageContentOutputText",
    "InputInputItemListOutputMessageContentOutputTextAnnotation",
    "InputInputItemListOutputMessageContentOutputTextAnnotationFileCitation",
    "InputInputItemListOutputMessageContentOutputTextAnnotationURLCitation",
    "InputInputItemListOutputMessageContentOutputTextAnnotationFilePath",
    "InputInputItemListOutputMessageContentOutputTextLogprob",
    "InputInputItemListOutputMessageContentOutputTextLogprobTopLogprob",
    "InputInputItemListOutputMessageContentRefusal",
    "InputInputItemListOutputMessageContentOutputAudio",
    "InputInputItemListFileSearchToolCall",
    "InputInputItemListFileSearchToolCallResult",
    "InputInputItemListFileSearchToolCallResultContent",
    "InputInputItemListFileSearchToolCallResultContentInputText",
    "InputInputItemListFileSearchToolCallResultContentInputAudio",
    "InputInputItemListFileSearchToolCallResultContentInputImage",
    "InputInputItemListFileSearchToolCallResultContentInputFile",
    "InputInputItemListFileSearchToolCallResultContentOutputText",
    "InputInputItemListFileSearchToolCallResultContentOutputTextAnnotation",
    "InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFileCitation",
    "InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationURLCitation",
    "InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFilePath",
    "InputInputItemListFileSearchToolCallResultContentOutputTextLogprob",
    "InputInputItemListFileSearchToolCallResultContentOutputTextLogprobTopLogprob",
    "InputInputItemListFileSearchToolCallResultContentRefusal",
    "InputInputItemListFileSearchToolCallResultContentOutputAudio",
    "InputInputItemListComputerToolCall",
    "InputInputItemListComputerToolCallAction",
    "InputInputItemListComputerToolCallActionClick",
    "InputInputItemListComputerToolCallActionDoubleClick",
    "InputInputItemListComputerToolCallActionDrag",
    "InputInputItemListComputerToolCallActionDragPath",
    "InputInputItemListComputerToolCallActionKeypress",
    "InputInputItemListComputerToolCallActionMove",
    "InputInputItemListComputerToolCallActionScreenshot",
    "InputInputItemListComputerToolCallActionScroll",
    "InputInputItemListComputerToolCallActionType",
    "InputInputItemListComputerToolCallActionWait",
    "InputInputItemListComputerToolCallOutput",
    "InputInputItemListComputerToolCallOutputOutput",
    "InputInputItemListWebSearchToolCall",
    "InputInputItemListFunctionToolCall",
    "InputInputItemListFunctionToolCallOutput",
    "InputInputItemListItemReference",
    "Text",
    "TextFormat",
    "TextFormatJSONSchema",
    "ToolChoice",
    "ToolChoiceToolChoiceTypes",
    "ToolChoiceToolChoiceFunction",
    "Tool",
    "ToolFileSearch",
    "ToolFunction",
    "ToolComputerPreview",
    "ToolWebSearch",
    "ToolWebSearchLocation",
]


class ResponseCreateParams(TypedDict, total=False):
    input: Required[Union[str, Iterable[InputInputItemList]]]
    """Text or image inputs to the model, used to generate a response.

    Can also contain previous assistant messages to manually provide conversation
    state to the model if you are not using the `previous_response_id` parameter
    shown below. The input array can also contain the results of function calls to
    custom code.

    Learn more:

    - [Text inputs and outputs](https://platform.openai.com/docs/guides/text)
    - [Image inputs](https://platform.openai.com/docs/guides/images)
    - [Conversation state](https://platform.openai.com/docs/guides/conversation-state)
    - [Function calling](https://platform.openai.com/docs/guides/function-calling)
    """

    model: Required[
        Union[
            str,
            Literal[
                "o3-mini",
                "o3-mini-2025-01-31",
                "o1",
                "o1-2024-12-17",
                "o1-preview",
                "o1-preview-2024-09-12",
                "o1-mini",
                "o1-mini-2024-09-12",
                "gpt-4o",
                "gpt-4o-2024-11-20",
                "gpt-4o-2024-08-06",
                "gpt-4o-2024-05-13",
                "gpt-4o-audio-preview",
                "gpt-4o-audio-preview-2024-10-01",
                "gpt-4o-audio-preview-2024-12-17",
                "gpt-4o-mini-audio-preview",
                "gpt-4o-mini-audio-preview-2024-12-17",
                "chatgpt-4o-latest",
                "gpt-4o-mini",
                "gpt-4o-mini-2024-07-18",
                "gpt-4-turbo",
                "gpt-4-turbo-2024-04-09",
                "gpt-4-0125-preview",
                "gpt-4-turbo-preview",
                "gpt-4-1106-preview",
                "gpt-4-vision-preview",
                "gpt-4",
                "gpt-4-0314",
                "gpt-4-0613",
                "gpt-4-32k",
                "gpt-4-32k-0314",
                "gpt-4-32k-0613",
                "gpt-3.5-turbo",
                "gpt-3.5-turbo-16k",
                "gpt-3.5-turbo-0301",
                "gpt-3.5-turbo-0613",
                "gpt-3.5-turbo-1106",
                "gpt-3.5-turbo-0125",
                "gpt-3.5-turbo-16k-0613",
            ],
        ]
    ]
    """Model ID used to generate the response, like `gpt-4o` or `o1`.

    OpenAI offers a wide range of models with different capabilities, performance
    characteristics, and price points. Refer to the
    [model guide](https://platform.openai.com/docs/models) to browse and compare
    available models.
    """

    frequency_penalty: Optional[float]
    """Number between -2.0 and 2.0.

    Positive values penalize new tokens based on their existing frequency in the
    text so far, decreasing the model's likelihood to repeat the same line verbatim.
    """

    include: Optional[List[Literal["output[*].message.logprobs", "output[*].file_search_call.search_results"]]]
    """Specify additional output data to include in the model response.

    Currently supported values are:

    - `output[*].message.logprobs`: Include the log probabilities of the model's
      response.
    - `output[*].file_search_call.search_results`: Include the search results of the
      file search tool call.
    """

    max_completion_tokens: Optional[int]
    """
    An upper bound for the number of tokens that can be generated for a completion,
    including visible output tokens and
    [reasoning tokens](https://platform.openai.com/docs/guides/reasoning).
    """

    metadata: Optional[Metadata]
    """Set of 16 key-value pairs that can be attached to an object.

    This can be useful for storing additional information about the object in a
    structured format, and querying for objects via API or the dashboard.

    Keys are strings with a maximum length of 64 characters. Values are strings with
    a maximum length of 512 characters.
    """

    modalities: Optional[List[Literal["text"]]]
    """
    Output types that you would like the model to generate. Most models are capable
    of generating text, which is the default:

    `["text"]`

    This API will soon support other output modalities, including audio and images.
    """

    parallel_tool_calls: Optional[bool]
    """Whether to allow the model to run tool calls in parallel."""

    presence_penalty: Optional[float]
    """Number between -2.0 and 2.0.

    Positive values penalize new tokens based on whether they appear in the text so
    far, increasing the model's likelihood to talk about new topics.
    """

    previous_response_id: Optional[str]
    """The unique ID of the previous response to the model.

    Use this to create multi-turn conversations. Learn more about
    [conversation state](https://platform.openai.com/docs/guides/conversation-state).
    """

    reasoning_effort: Optional[ChatCompletionReasoningEffort]
    """**o-series models only**

    Constrains effort on reasoning for
    [reasoning models](https://platform.openai.com/docs/guides/reasoning). Currently
    supported values are `low`, `medium`, and `high`. Reducing reasoning effort can
    result in faster responses and fewer tokens used on reasoning in a response.
    """

    service_tier: Optional[Literal["auto", "default"]]
    """Specifies the latency tier to use for processing the request.

    This parameter is relevant for customers subscribed to the scale tier service:

    - If set to 'auto', and the Project is Scale tier enabled, the system will
      utilize scale tier credits until they are exhausted.
    - If set to 'auto', and the Project is not Scale tier enabled, the request will
      be processed using the default service tier with a lower uptime SLA and no
      latency guarentee.
    - If set to 'default', the request will be processed using the default service
      tier with a lower uptime SLA and no latency guarentee.
    - When not set, the default behavior is 'auto'.

    When this parameter is set, the response body will include the `service_tier`
    utilized.
    """

    stop: Union[Optional[str], List[str]]
    """Up to 4 sequences where the API will stop generating further tokens."""

    store: Optional[bool]
    """Whether to store the generated model response for later retrieval via API."""

    stream: Optional[bool]
    """
    If set to true, the model response data will be streamed to the client as it is
    generated using
    [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format).
    See the
    [Streaming section below](https://platform.openai.com/docs/api-reference/responses-streaming)
    for more information.
    """

    temperature: Optional[float]
    """What sampling temperature to use, between 0 and 2.

    Higher values like 0.8 will make the output more random, while lower values like
    0.2 will make it more focused and deterministic. We generally recommend altering
    this or `top_p` but not both.
    """

    text: Text
    """Configuration options for a text response from the model.

    Can be plain text or structured JSON data. Learn more:

    - [Text inputs and outputs](https://platform.openai.com/docs/guides/text)
    - [Structured Outputs](https://platform.openai.com/docs/guides/structured-outputs)
    """

    tool_choice: ToolChoice
    """
    How the model should select which tool (or tools) to use when generating a
    response. See the `tools` parameter to see how to specify which tools the model
    can call.
    """

    tools: Optional[Iterable[Tool]]
    """An array of tools the model may call while generating a response.

    You can specify which tool to use by setting the `tool_choice` parameter.

    The two categories of tools you can provide the model are:

    - **Hosted tools**: Tools that are provided by OpenAI that extend the model's
      capabilities, like
      [web search](https://platform.openai.com/docs/guides/tools-web-search) or
      [file search](https://platform.openai.com/docs/guides/tools-file-search).
      Learn more about
      [hosted tools](https://platform.openai.com/docs/guides/tools).
    - **Function calls (custom tools)**: Functions that are defined by you, enabling
      the model to call your own code. Learn more about
      [function calling](https://platform.openai.com/docs/guides/function-calling).
    """

    top_logprobs: Optional[int]
    """
    An integer between 0 and 20 specifying the number of most likely tokens to
    return at each token position, each with an associated log probability.
    `logprobs` must be set to `true` if this parameter is used.
    """

    top_p: Optional[float]
    """
    An alternative to sampling with temperature, called nucleus sampling, where the
    model considers the results of the tokens with top_p probability mass. So 0.1
    means only the tokens comprising the top 10% probability mass are considered.

    We generally recommend altering this or `temperature` but not both.
    """

    truncation: Optional[Literal["auto", "disabled"]]
    """The truncation strategy to use for the model response.

    - `auto`: If the context of this response and previous ones exceeds the model's
      context window size, the model will truncate the response to fit the context
      window by dropping input items in the middle of the conversation.
    - `disabled` (default): If a model response will exceed the context window size
      for a model, the request will fail with a 400 error.
    """

    user: str
    """
    A unique identifier representing your end-user, which can help OpenAI to monitor
    and detect abuse.
    [Learn more](https://platform.openai.com/docs/guides/safety-best-practices#end-user-ids).
    """


class InputInputItemListEasyInputMessageContentInputItemListInputText(TypedDict, total=False):
    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListEasyInputMessageContentInputItemListInputAudio(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded audio data."""

    format: Required[Literal["mp3", "wav"]]
    """The format of the audio data. Currently supported formats are `mp3` and `wav`."""

    type: Required[Literal["input_audio"]]
    """The type of the input item. Always `input_audio`."""


class InputInputItemListEasyInputMessageContentInputItemListInputImage(TypedDict, total=False):
    detail: Required[Literal["high", "low", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`. Defaults to `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str]
    """The ID of the file to be sent to the model."""

    image_url: Optional[str]
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListEasyInputMessageContentInputItemListInputFile(TypedDict, total=False):
    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_name: str
    """The name of the file to be sent to the model."""


InputInputItemListEasyInputMessageContentInputItemList: TypeAlias = Union[
    InputInputItemListEasyInputMessageContentInputItemListInputText,
    InputInputItemListEasyInputMessageContentInputItemListInputAudio,
    InputInputItemListEasyInputMessageContentInputItemListInputImage,
    InputInputItemListEasyInputMessageContentInputItemListInputFile,
]


class InputInputItemListEasyInputMessage(TypedDict, total=False):
    content: Required[Union[str, Iterable[InputInputItemListEasyInputMessageContentInputItemList]]]
    """
    Text, image, or audio input to the model, used to generate a response. Can also
    contain previous assistant responses.
    """

    role: Required[Literal["user", "assistant", "system", "developer"]]
    """The role of the message input.

    One of `user`, `assistant`, `system`, or `developer`.
    """


class InputInputItemListInputMessageContentInputText(TypedDict, total=False):
    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListInputMessageContentInputAudio(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded audio data."""

    format: Required[Literal["mp3", "wav"]]
    """The format of the audio data. Currently supported formats are `mp3` and `wav`."""

    type: Required[Literal["input_audio"]]
    """The type of the input item. Always `input_audio`."""


class InputInputItemListInputMessageContentInputImage(TypedDict, total=False):
    detail: Required[Literal["high", "low", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`. Defaults to `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str]
    """The ID of the file to be sent to the model."""

    image_url: Optional[str]
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListInputMessageContentInputFile(TypedDict, total=False):
    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_name: str
    """The name of the file to be sent to the model."""


InputInputItemListInputMessageContent: TypeAlias = Union[
    InputInputItemListInputMessageContentInputText,
    InputInputItemListInputMessageContentInputAudio,
    InputInputItemListInputMessageContentInputImage,
    InputInputItemListInputMessageContentInputFile,
]


class InputInputItemListInputMessage(TypedDict, total=False):
    content: Required[Iterable[InputInputItemListInputMessageContent]]
    """The content of the message input."""

    role: Required[Literal["user", "system", "developer"]]
    """The role of the message input. One of `user`, `system`, or `developer`."""


class InputInputItemListOutputMessageContentOutputTextAnnotationFileCitation(TypedDict, total=False):
    file_id: Required[str]
    """The ID of the file."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_citation"]]
    """The type of the file citation. Always `file_citation`."""


class InputInputItemListOutputMessageContentOutputTextAnnotationURLCitation(TypedDict, total=False):
    index: Required[float]
    """The character index where the URL is used in the response."""

    title: Required[str]
    """The title of the web resource."""

    type: Required[Literal["url_citation"]]
    """The type of the URL citation. Always `url_citation`."""

    url: Required[str]
    """The URL of the web resource."""


class InputInputItemListOutputMessageContentOutputTextAnnotationFilePath(TypedDict, total=False):
    file_id: Required[str]
    """The ID of the file."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_path"]]
    """The type of the file path. Always `file_path`."""


InputInputItemListOutputMessageContentOutputTextAnnotation: TypeAlias = Union[
    InputInputItemListOutputMessageContentOutputTextAnnotationFileCitation,
    InputInputItemListOutputMessageContentOutputTextAnnotationURLCitation,
    InputInputItemListOutputMessageContentOutputTextAnnotationFilePath,
]


class InputInputItemListOutputMessageContentOutputTextLogprobTopLogprob(TypedDict, total=False):
    token: Required[str]
    """The token that was used to generate the log probability."""

    bytes: Required[Iterable[int]]
    """The bytes that were used to generate the log probability."""

    logprob: Required[float]
    """The log probability of the token."""


class InputInputItemListOutputMessageContentOutputTextLogprob(TypedDict, total=False):
    token: Required[str]
    """The token that was used to generate the log probability."""

    bytes: Required[Iterable[int]]
    """The bytes that were used to generate the log probability."""

    logprob: Required[float]
    """The log probability of the token."""

    top_logprobs: Optional[Iterable[InputInputItemListOutputMessageContentOutputTextLogprobTopLogprob]]


class InputInputItemListOutputMessageContentOutputText(TypedDict, total=False):
    annotations: Required[Iterable[InputInputItemListOutputMessageContentOutputTextAnnotation]]
    """The annotations of the text output."""

    text: Required[str]
    """The text output from the model."""

    type: Required[Literal["output_text"]]
    """The type of the output text. Always `output_text`."""

    logprobs: Optional[Iterable[InputInputItemListOutputMessageContentOutputTextLogprob]]
    """The log probabilities of the tokens in the text output."""


class InputInputItemListOutputMessageContentRefusal(TypedDict, total=False):
    refusal: Required[str]
    """The refusal explanationfrom the model."""

    type: Required[Literal["refusal"]]
    """The type of the refusal. Always `refusal`."""


class InputInputItemListOutputMessageContentOutputAudio(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded audio data from the model."""

    transcript: Required[str]
    """The transcript of the audio data from the model."""

    type: Required[Literal["output_audio"]]
    """The type of the output audio. Always `output_audio`."""


InputInputItemListOutputMessageContent: TypeAlias = Union[
    InputInputItemListOutputMessageContentOutputText,
    InputInputItemListOutputMessageContentRefusal,
    InputInputItemListOutputMessageContentOutputAudio,
]


class InputInputItemListOutputMessage(TypedDict, total=False):
    id: Required[str]
    """The unique ID of the output message."""

    content: Required[Iterable[InputInputItemListOutputMessageContent]]
    """The content of the output message."""

    role: Required[Literal["assistant"]]
    """The role of the output message. Always `assistant`."""

    type: Required[Literal["message"]]
    """The type of the output message. Always `message`."""


class InputInputItemListFileSearchToolCallResultContentInputText(TypedDict, total=False):
    text: Required[str]
    """The text input to the model."""

    type: Required[Literal["input_text"]]
    """The type of the input item. Always `input_text`."""


class InputInputItemListFileSearchToolCallResultContentInputAudio(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded audio data."""

    format: Required[Literal["mp3", "wav"]]
    """The format of the audio data. Currently supported formats are `mp3` and `wav`."""

    type: Required[Literal["input_audio"]]
    """The type of the input item. Always `input_audio`."""


class InputInputItemListFileSearchToolCallResultContentInputImage(TypedDict, total=False):
    detail: Required[Literal["high", "low", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`. Defaults to `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str]
    """The ID of the file to be sent to the model."""

    image_url: Optional[str]
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListFileSearchToolCallResultContentInputFile(TypedDict, total=False):
    type: Required[Literal["input_file"]]
    """The type of the input item. Always `input_file`."""

    file_data: str
    """The content of the file to be sent to the model."""

    file_id: str
    """The ID of the file to be sent to the model."""

    file_name: str
    """The name of the file to be sent to the model."""


class InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFileCitation(TypedDict, total=False):
    file_id: Required[str]
    """The ID of the file."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_citation"]]
    """The type of the file citation. Always `file_citation`."""


class InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationURLCitation(TypedDict, total=False):
    index: Required[float]
    """The character index where the URL is used in the response."""

    title: Required[str]
    """The title of the web resource."""

    type: Required[Literal["url_citation"]]
    """The type of the URL citation. Always `url_citation`."""

    url: Required[str]
    """The URL of the web resource."""


class InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFilePath(TypedDict, total=False):
    file_id: Required[str]
    """The ID of the file."""

    index: Required[int]
    """The index of the file in the list of files."""

    type: Required[Literal["file_path"]]
    """The type of the file path. Always `file_path`."""


InputInputItemListFileSearchToolCallResultContentOutputTextAnnotation: TypeAlias = Union[
    InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFileCitation,
    InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationURLCitation,
    InputInputItemListFileSearchToolCallResultContentOutputTextAnnotationFilePath,
]


class InputInputItemListFileSearchToolCallResultContentOutputTextLogprobTopLogprob(TypedDict, total=False):
    token: Required[str]
    """The token that was used to generate the log probability."""

    bytes: Required[Iterable[int]]
    """The bytes that were used to generate the log probability."""

    logprob: Required[float]
    """The log probability of the token."""


class InputInputItemListFileSearchToolCallResultContentOutputTextLogprob(TypedDict, total=False):
    token: Required[str]
    """The token that was used to generate the log probability."""

    bytes: Required[Iterable[int]]
    """The bytes that were used to generate the log probability."""

    logprob: Required[float]
    """The log probability of the token."""

    top_logprobs: Optional[Iterable[InputInputItemListFileSearchToolCallResultContentOutputTextLogprobTopLogprob]]


class InputInputItemListFileSearchToolCallResultContentOutputText(TypedDict, total=False):
    annotations: Required[Iterable[InputInputItemListFileSearchToolCallResultContentOutputTextAnnotation]]
    """The annotations of the text output."""

    text: Required[str]
    """The text output from the model."""

    type: Required[Literal["output_text"]]
    """The type of the output text. Always `output_text`."""

    logprobs: Optional[Iterable[InputInputItemListFileSearchToolCallResultContentOutputTextLogprob]]
    """The log probabilities of the tokens in the text output."""


class InputInputItemListFileSearchToolCallResultContentRefusal(TypedDict, total=False):
    refusal: Required[str]
    """The refusal explanationfrom the model."""

    type: Required[Literal["refusal"]]
    """The type of the refusal. Always `refusal`."""


class InputInputItemListFileSearchToolCallResultContentOutputAudio(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded audio data from the model."""

    transcript: Required[str]
    """The transcript of the audio data from the model."""

    type: Required[Literal["output_audio"]]
    """The type of the output audio. Always `output_audio`."""


InputInputItemListFileSearchToolCallResultContent: TypeAlias = Union[
    InputInputItemListFileSearchToolCallResultContentInputText,
    InputInputItemListFileSearchToolCallResultContentInputAudio,
    InputInputItemListFileSearchToolCallResultContentInputImage,
    InputInputItemListFileSearchToolCallResultContentInputFile,
    InputInputItemListFileSearchToolCallResultContentOutputText,
    InputInputItemListFileSearchToolCallResultContentRefusal,
    InputInputItemListFileSearchToolCallResultContentOutputAudio,
]


class InputInputItemListFileSearchToolCallResult(TypedDict, total=False):
    content: Iterable[InputInputItemListFileSearchToolCallResultContent]
    """The content returned from the file search tool call."""

    file_id: str
    """The unique ID of the file."""

    file_name: str
    """The name of the file."""

    score: float
    """The relevance score of the file."""


class InputInputItemListFileSearchToolCall(TypedDict, total=False):
    id: Required[str]
    """The unique ID of the file search tool call."""

    queries: Required[List[str]]
    """The queries used to search for files."""

    status: Required[Literal["in_progress", "searching", "completed"]]
    """The status of the file search tool call."""

    type: Required[Literal["file_search_call"]]
    """The type of the file search tool call. Always `file_search_call`."""

    results: Optional[Iterable[InputInputItemListFileSearchToolCallResult]]
    """The results of the file search tool call."""


class InputInputItemListComputerToolCallActionClick(TypedDict, total=False):
    button: Required[Literal["left", "right", "wheel", "back", "forward"]]
    """Indicates which mouse button was pressed during the click."""

    type: Required[Literal["click"]]
    """Specifies the event type.

    For a click action, this property is always set to "click".
    """

    x: Required[float]
    """The x-coordinate where the click occurred."""

    y: Required[float]
    """The y-coordinate where the click occurred."""


class InputInputItemListComputerToolCallActionDoubleClick(TypedDict, total=False):
    type: Required[Literal["double_click"]]
    """Specifies the event type.

    For a double click action, this property is always set to "double_click".
    """

    x: Required[float]
    """The x-coordinate where the double click occurred."""

    y: Required[float]
    """The y-coordinate where the double click occurred."""


class InputInputItemListComputerToolCallActionDragPath(TypedDict, total=False):
    x: Required[float]
    """The x-coordinate for a point in the drag path."""

    y: Required[float]
    """The y-coordinate for a point in the drag path."""


class InputInputItemListComputerToolCallActionDrag(TypedDict, total=False):
    path: Required[Iterable[InputInputItemListComputerToolCallActionDragPath]]
    """An array of coordinates representing the path of the drag action."""

    type: Required[Literal["drag"]]
    """Specifies the event type.

    For a drag action, this property is always set to "drag".
    """


class InputInputItemListComputerToolCallActionKeypress(TypedDict, total=False):
    keys: Required[List[str]]
    """The combination of keys that were pressed during the keypress action."""

    type: Required[Literal["keypress"]]
    """Specifies the event type.

    For a keypress action, this property is always set to "keypress".
    """


class InputInputItemListComputerToolCallActionMove(TypedDict, total=False):
    type: Required[Literal["move"]]
    """Specifies the event type.

    For a move action, this property is always set to "move".
    """

    x: Required[float]
    """The x-coordinate to move to."""

    y: Required[float]
    """The y-coordinate to move to."""


class InputInputItemListComputerToolCallActionScreenshot(TypedDict, total=False):
    type: Required[Literal["screenshot"]]
    """Specifies the event type.

    For a screenshot action, this property is always set to "screenshot".
    """


class InputInputItemListComputerToolCallActionScroll(TypedDict, total=False):
    scroll_x: Required[float]
    """The horizontal scroll distance."""

    scroll_y: Required[float]
    """The vertical scroll distance."""

    type: Required[Literal["scroll"]]
    """Specifies the event type.

    For a scroll action, this property is always set to "scroll".
    """

    x: Required[float]
    """The x-coordinate where the scroll occurred."""

    y: Required[float]
    """The y-coordinate where the scroll occurred."""


class InputInputItemListComputerToolCallActionType(TypedDict, total=False):
    text: Required[str]
    """The text to type."""

    type: Required[Literal["type"]]
    """Specifies the event type.

    For a type action, this property is always set to "type".
    """


class InputInputItemListComputerToolCallActionWait(TypedDict, total=False):
    type: Required[Literal["wait"]]
    """Specifies the event type.

    For a wait action, this property is always set to "wait".
    """

    wait_milliseconds: Required[float]
    """The duration to wait, in milliseconds."""


InputInputItemListComputerToolCallAction: TypeAlias = Union[
    InputInputItemListComputerToolCallActionClick,
    InputInputItemListComputerToolCallActionDoubleClick,
    InputInputItemListComputerToolCallActionDrag,
    InputInputItemListComputerToolCallActionKeypress,
    InputInputItemListComputerToolCallActionMove,
    InputInputItemListComputerToolCallActionScreenshot,
    InputInputItemListComputerToolCallActionScroll,
    InputInputItemListComputerToolCallActionType,
    InputInputItemListComputerToolCallActionWait,
]


class InputInputItemListComputerToolCall(TypedDict, total=False):
    id: Required[str]

    action: Required[InputInputItemListComputerToolCallAction]
    """A click action."""

    type: Required[Literal["computer_call"]]


class InputInputItemListComputerToolCallOutputOutput(TypedDict, total=False):
    detail: Required[Literal["high", "low", "auto"]]
    """The detail level of the image to be sent to the model.

    One of `high`, `low`, or `auto`. Defaults to `auto`.
    """

    type: Required[Literal["input_image"]]
    """The type of the input item. Always `input_image`."""

    file_id: Optional[str]
    """The ID of the file to be sent to the model."""

    image_url: Optional[str]
    """The URL of the image to be sent to the model.

    A fully qualified URL or base64 encoded image in a data URL.
    """


class InputInputItemListComputerToolCallOutput(TypedDict, total=False):
    id: Required[str]
    """The ID of the computer tool call output."""

    call_id: Required[str]
    """The ID of the computer tool call that produced the output."""

    output: Required[InputInputItemListComputerToolCallOutputOutput]
    """An image input to the model.

    Learn about [image inputs](https://platform.openai.com/docs/guides/vision).
    """

    type: Required[Literal["computer_call_output"]]
    """The type of the computer tool call output. Always `computer_call_output`."""


class InputInputItemListWebSearchToolCall(TypedDict, total=False):
    id: Required[str]
    """The unique ID of the web search tool call."""

    status: Required[Literal["in_progress", "completed"]]
    """The status of the web search tool call."""

    type: Required[Literal["web_search_call"]]
    """The type of the web search tool call. Always `web_search_call`."""


class InputInputItemListFunctionToolCall(TypedDict, total=False):
    id: Required[str]
    """The unique ID of the function tool call."""

    arguments: Required[str]
    """A JSON string of the arguments to pass to the function."""

    name: Required[str]
    """The name of the function to run."""

    type: Required[Literal["function_call"]]
    """The type of the function tool call. Always `function_call`."""


class InputInputItemListFunctionToolCallOutput(TypedDict, total=False):
    id: Required[str]
    """The unique ID of the function tool call output."""

    call_id: Required[str]
    """The unique ID of the function tool call generated by the model."""

    output: Required[str]
    """A JSON string of the output of the function tool call."""

    type: Required[Literal["function_call_output"]]
    """The type of the function tool call output. Always `function_call_output`."""


class InputInputItemListItemReference(TypedDict, total=False):
    id: Required[str]
    """The ID of the item to reference."""

    type: Required[Literal["item_reference"]]
    """The `type` of this object is always `item_reference`."""


InputInputItemList: TypeAlias = Union[
    InputInputItemListEasyInputMessage,
    InputInputItemListInputMessage,
    InputInputItemListOutputMessage,
    InputInputItemListFileSearchToolCall,
    InputInputItemListComputerToolCall,
    InputInputItemListComputerToolCallOutput,
    InputInputItemListWebSearchToolCall,
    InputInputItemListFunctionToolCall,
    InputInputItemListFunctionToolCallOutput,
    InputInputItemListItemReference,
]


class TextFormatJSONSchema(TypedDict, total=False):
    schema: Required[Dict[str, object]]
    """
    The schema for the response format, described as a JSON Schema object. Learn how
    to build JSON schemas [here](https://json-schema.org/).
    """

    type: Required[Literal["json_schema"]]
    """The type of response format being defined. Always `json_schema`."""

    description: str
    """
    A description of what the response format is for, used by the model to determine
    how to respond in the format.
    """

    name: str
    """The name of the response format.

    Must be a-z, A-Z, 0-9, or contain underscores and dashes, with a maximum length
    of 64.
    """

    strict: Optional[bool]
    """
    Whether to enable strict schema adherence when generating the output. If set to
    true, the model will always follow the exact schema defined in the `schema`
    field. Only a subset of JSON Schema is supported when `strict` is `true`. To
    learn more, read the
    [Structured Outputs guide](https://platform.openai.com/docs/guides/structured-outputs).
    """


TextFormat: TypeAlias = Union[ResponseFormatText, TextFormatJSONSchema, ResponseFormatJSONObject]


class Text(TypedDict, total=False):
    format: TextFormat
    """An object specifying the format that the model must output.

    Configuring `{ "type": "json_schema" }` enables Structured Outputs, which
    ensures the model will match your supplied JSON schema. Learn more in the
    [Structured Outputs guide](https://platform.openai.com/docs/guides/structured-outputs).

    The default format is `{ "type": "text" }` with no additional options.

    **Not recommended for gpt-4o and newer models:**

    Setting to `{ "type": "json_object" }` enables the older JSON mode, which
    ensures the message the model generates is valid JSON. Using `json_schema` is
    preferred for models that support it.
    """

    stop: Union[Optional[str], List[str], None]
    """Up to 4 sequences where the API will stop generating further tokens.

    The returned text will not contain the stop sequence.
    """


class ToolChoiceToolChoiceTypes(TypedDict, total=False):
    type: Required[Literal["file_search", "web_search", "computer-preview"]]
    """The type of hosted tool the model should to use.

    Learn more about [hosted tools](https://platform.openai.com/docs/guides/tools).

    Allowed values are:

    - `file_search`
    - `web_search`
    - `computer-preview`
    """


class ToolChoiceToolChoiceFunction(TypedDict, total=False):
    name: Required[str]
    """The name of the function to call."""

    type: Required[Literal["function"]]
    """For function calling, the type is always `function`."""


ToolChoice: TypeAlias = Union[
    Literal["none", "auto", "required"], ToolChoiceToolChoiceTypes, ToolChoiceToolChoiceFunction
]


class ToolFileSearch(TypedDict, total=False):
    max_num_results: Required[int]
    """The maximum number of results to return."""

    type: Required[Literal["file_search"]]
    """The type of the file search tool. Always `file_search`."""

    vector_store_ids: Required[List[str]]
    """The IDs of the vector stores to search."""


class ToolFunction(TypedDict, total=False):
    name: Required[str]
    """The name of the function to call."""

    parameters: Required[Dict[str, object]]
    """A JSON schema object describing the parameters of the function."""

    strict: Required[bool]
    """Whether to enforce strict parameter validation."""

    type: Required[Literal["function"]]
    """The type of the function tool. Always `function`."""

    description: Optional[str]
    """A description of the function.

    Used by the model to determine whether or not to call the function.
    """


class ToolComputerPreview(TypedDict, total=False):
    display_height: Required[float]
    """The height of the computer display."""

    display_width: Required[float]
    """The width of the computer display."""

    environment_type: Required[Literal["mac", "windows", "ubuntu", "browser"]]
    """The type of computer environment to control."""

    type: Required[Literal["computer-preview"]]
    """The type of the computer use tool. Always `computer-preview`."""


class ToolWebSearchLocation(TypedDict, total=False):
    time_zone: Optional[str]
    """The time zone of the user."""

    user_city: Optional[str]
    """The city of the user."""

    user_country: Optional[str]
    """The country of the user."""

    user_region: Optional[str]
    """The region of the user."""


class ToolWebSearch(TypedDict, total=False):
    type: Required[Literal["web_search"]]
    """The type of the web search tool. Always `web_search`."""

    location: Optional[ToolWebSearchLocation]
    """Optional location parameters for the search."""

    sites: Optional[List[str]]
    """An optional list of domains to constrain the search to. Examples:

    `["platform.openai.com", "developer.mozilla.org"]`
    """


Tool: TypeAlias = Union[ToolFileSearch, ToolFunction, ToolComputerPreview, ToolWebSearch]
