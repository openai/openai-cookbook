# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List
from typing_extensions import Literal, TypedDict

__all__ = ["ResponseRetrieveParams"]


class ResponseRetrieveParams(TypedDict, total=False):
    include: List[Literal["output[*].message.logprobs", "output[*].file_search_call.search_results"]]
    """Additional fields to include in the response.

    See the `include` parameter for Response creation above for more information.
    """
