# HubSpot Funnel Analysis Plugin

Analyze MQL → PQL → SQL → Deal → Customer funnel performance using HubSpot data directly from Claude Cowork.

## What It Does

This plugin gives Claude the knowledge and commands to run HubSpot funnel analysis — the same analyses our Python scripts perform, but powered by Claude + HubSpot MCP connector.

### Slash Commands

| Command | What It Does |
|---------|-------------|
| `/hubspot-funnel:funnel-report 2026-02` | Full funnel: MQL → PQL → SQL → Deal → Customer with conversion rates |
| `/hubspot-funnel:pql-sql-analysis 2026-02` | PQL timing analysis: did product activation happen before or after sales? |
| `/hubspot-funnel:deal-reconciliation 2026-02` | Verify SQL contacts and deals match HubSpot data |

### Skills (auto-triggered)

| Skill | When It Activates |
|-------|-------------------|
| **funnel-definitions** | When you ask about MQLs, PQLs, SQLs, conversion rates, lifecycle stages |
| **hubspot-api-patterns** | When Claude makes HubSpot API calls — ensures correct filtering and avoids known gotchas |

## Setup Instructions

### Step 1: Open Cowork

Go to [claude.ai](https://claude.ai) → Click **Cowork** tab at the top.

### Step 2: Install the Plugin

1. Click **Plugins** in the left sidebar
2. Click **Upload plugin**
3. Select the `hubspot-funnel` folder (this entire directory)
4. The plugin will appear in your installed plugins list

### Step 3: Connect HubSpot

1. In Cowork, go to **Settings** → **Connectors**
2. Find **HubSpot** and click **Connect**
3. Authenticate with your HubSpot account
4. Grant access to Contacts and Deals

### Step 4: Use It

Start a new Cowork session and type:

```
/hubspot-funnel:funnel-report 2026-02
```

Or just ask naturally:

> "Analyze the MQL to SQL funnel for February 2026"
> "How many PQLs converted to SQL last month?"
> "Show me the deal reconciliation for January"

Claude will use the funnel definitions and API patterns automatically.

## For Teammates

Share this folder with your teammates. Each person needs to:

1. **Upload the plugin** to their Cowork (Plugins → Upload plugin)
2. **Connect HubSpot** in their Cowork settings (one-time auth)
3. Start using the commands

> ⚠️ Plugins are currently saved locally per user. Organization-wide plugin sharing is coming in a future Claude update.

## Plugin Structure

```
hubspot-funnel/
├── .claude-plugin/
│   └── plugin.json          ← Plugin metadata
├── .claude/
│   └── settings.local.json  ← Company-specific settings
├── .mcp.json                ← HubSpot MCP connector
├── commands/
│   ├── funnel-report.md     ← /hubspot-funnel:funnel-report
│   ├── pql-sql-analysis.md  ← /hubspot-funnel:pql-sql-analysis
│   └── deal-reconciliation.md ← /hubspot-funnel:deal-reconciliation
├── skills/
│   ├── funnel-definitions/
│   │   └── SKILL.md         ← MQL/PQL/SQL/Customer definitions
│   └── hubspot-api-patterns/
│       └── SKILL.md         ← API filtering rules, gotchas, best practices
└── README.md
```

## Business Definitions

| Stage | Definition | HubSpot Field |
|-------|-----------|---------------|
| **MQL** | Contact created (excl. Usuario Invitado) | `createdate` |
| **PQL** | Product activation during trial | `activo=true` + `fecha_activo` |
| **SQL** | Associated to deal (opportunity) | `hs_v2_date_entered_opportunity` + `num_associated_deals > 0` |
| **Customer** | Deal closed-won | `hs_is_closed_won=true` |
