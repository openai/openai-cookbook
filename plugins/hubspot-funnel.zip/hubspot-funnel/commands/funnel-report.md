---
description: Full MQL → PQL → SQL → Deal → Customer funnel analysis for a given month
argument-hint: "<month, e.g. 2026-02 or 'february 2026'>"
---

# /funnel-report

Run a comprehensive MQL → PQL → SQL → Deal → Customer funnel analysis for contacts created in a given month using HubSpot data.

## Usage

```
/hubspot-funnel:funnel-report 2026-02
```

---

## How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│                    FUNNEL REPORT                                 │
├─────────────────────────────────────────────────────────────────┤
│  1. Fetch all contacts created in the month                      │
│  2. Classify each contact: MQL → PQL → SQL → Deal → Customer    │
│  3. Calculate conversion rates at each stage                     │
│  4. Compare PQL vs Non-PQL performance                           │
│  5. Show revenue by journey path                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## What I Need From You

- **Month**: Which month to analyze (e.g. "2026-02", "january 2026", "last month")
- **MTD or full month**: If current month, I'll do month-to-date automatically

---

## Step-by-Step Execution

### Step 1: Fetch Contacts Created in Period

Search HubSpot contacts with these filters (ALL must match):
- `createdate` GTE `{month}-01T00:00:00Z`
- `createdate` LTE `{last-day-of-month}T23:59:59Z`
- `lead_source` HAS_PROPERTY (exclude nulls)
- `lead_source` NEQ `Usuario Invitado` (exclude team invitations)

Fetch these properties for each contact:
`email, firstname, lastname, createdate, lifecyclestage, lead_source, activo, fecha_activo, hs_v2_date_entered_opportunity, hs_v2_date_entered_customer, num_associated_deals, fit_score_contador`

**CRITICAL**: Always use HAS_PROPERTY + NEQ together for lead_source filtering. Using only NEQ includes contacts with null lead_source, which does NOT match HubSpot UI's "is none of" behavior.

### Step 2: Classify Each Contact

For each contact, determine:

**MQL**: All fetched contacts are MQLs (they signed up for trial and validated email — that's how they get created in HubSpot)

**PQL (Product Qualified Lead)**:
- `activo` = `true` AND `fecha_activo` is populated
- PQL date = `fecha_activo`

**SQL (Sales Qualified Lead)**:
- `hs_v2_date_entered_opportunity` is populated AND contact has at least 1 deal associated (`num_associated_deals > 0`)
- SQL date = `hs_v2_date_entered_opportunity`
- **IMPORTANT**: Contacts with hs_v2_date_entered_opportunity but 0 deals are NOT real SQLs — they are manual lifecycle overrides. Exclude them.

**Customer**:
- `hs_v2_date_entered_customer` is populated OR lifecycle stage is "customer"

### Step 3: For SQL Contacts, Fetch Deal Details

For each SQL contact (has opportunity date + deals), look up their associated deals:
- Use HubSpot associations API: contacts → deals
- For each deal, get: `dealname, amount, dealstage, closedate, pipeline, hs_is_closed_won`
- Calculate: total revenue (sum of won deal amounts), number of won deals, number of total deals

### Step 4: Build Funnel Table

Present results as a funnel:

```
Stage                          │ Count    │ % of Previous │ % of Total
───────────────────────────────┼──────────┼───────────────┼───────────
1. Total Contacts (MQL)        │ {n}      │ —             │ 100.0%
2. PQL                         │ {n}      │ {x}%          │ {x}%
3. SQL (Deal Associated)       │ {n}      │ {x}%          │ {x}%
   └─ SQL from PQL             │ {n}      │ {x}% of PQLs  │ {x}%
4. Deal Won                    │ {n}      │ {x}% of SQLs  │ {x}%
5. Customer                    │ {n}      │ {x}%          │ {x}%
```

### Step 5: PQL vs Non-PQL Comparison

```
Metric                         │ PQL       │ Non-PQL     │ Difference
───────────────────────────────┼───────────┼─────────────┼───────────
SQL Rate                       │ {x}%      │ {x}%        │ +{x}pp
Deal Win Rate                  │ {x}%      │ {x}%        │ +{x}pp
Avg Revenue per Contact        │ ${x}      │ ${x}        │ +${x}
```

### Step 6: SQL Contact Detail Table

For each SQL contact, show:

| Email | Created | SQL Date | PQL? | Deals | Won | Revenue |
|-------|---------|----------|------|-------|-----|---------|

### Step 7: Journey Path Analysis

Group contacts by their journey:
- PQL → SQL → Deal Won
- PQL → SQL → Deal (not won)
- SQL → Deal Won (no PQL)
- SQL → Deal (not won, no PQL)
- PQL only (no SQL)
- MQL only (no PQL, no SQL)

Show count and average revenue per path.

---

## Important Notes

- Revenue should only count WON deals. Unwon deals show $0 revenue — this is correct behavior.
- The HubSpot API uses UTC timestamps. The HubSpot UI uses the account timezone (Argentina, UTC-3). There may be ~25 contact difference at month boundaries due to this.
- All numbers should match HubSpot's journey report "Contact record created → Deal record created" within the timezone margin.

---

## Tips

1. **Compare months** — Run for multiple months to spot trends: "Run funnel report for January and February 2026"
2. **Dig into SQLs** — If SQL count seems off, verify each SQL contact has deals: "Show me the SQL contacts and their deals"
3. **Revenue context** — Won revenue depends on deal stage, not pipeline amount
