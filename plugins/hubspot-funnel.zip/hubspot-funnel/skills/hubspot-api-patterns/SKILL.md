---
name: hubspot-api-patterns
description: HubSpot API patterns, gotchas, and best practices for contact and deal analysis. Use when making HubSpot API calls, building filters, fetching associations, or debugging data discrepancies. Triggers on HubSpot search queries, deal lookups, contact filtering, or API troubleshooting.
---

# HubSpot API Patterns & Gotchas

## Contact Search Filters

### Standard Contact Search for Funnel Analysis

When searching for contacts created in a month, always use this filter pattern:

**Filters** (all combined with AND in one filterGroup):
1. `createdate` GTE `{start}T00:00:00Z`
2. `createdate` LTE `{end}T23:59:59Z`
3. `lead_source` HAS_PROPERTY ← **CRITICAL: must come before NEQ**
4. `lead_source` NEQ `Usuario Invitado`

**Why HAS_PROPERTY + NEQ?**
- HubSpot API's `NEQ` operator includes records where the property is NULL/not set
- HubSpot UI's "is none of" filter excludes nulls
- Adding `HAS_PROPERTY` before `NEQ` matches the UI behavior
- Without it, you'll get ~25-30 extra contacts with null lead_source

### Pagination

HubSpot search API returns max 100 results per page. Always paginate:
- Check for `paging.next.after` in response
- Pass `after` parameter in next request
- Continue until no `paging.next` in response

Typical contact counts per month: 2,500-3,500 contacts (25-35 pages).

## Deal Associations

### Finding Deals for a Contact

Two approaches, in order of preference:

**1. Check `num_associated_deals` first**
- If `num_associated_deals = 0`, skip — no deals to look up
- This avoids unnecessary API calls for 99%+ of contacts

**2. Use Associations API**
- Endpoint: `/crm/v4/objects/contacts/{contactId}/associations/deals`
- Returns list of deal IDs
- Then batch-read deals with properties

### Batch Deal Reads

When you have multiple deal IDs, use batch read:
- Endpoint: `/crm/v3/objects/deals/batch/read`
- Send up to 100 deal IDs at once
- Request properties: `dealname, amount, dealstage, closedate, pipeline, hs_is_closed_won, createdate, hubspot_owner_id`

## Common Data Quality Issues

### False SQLs (Opportunity date but no deals)

**Problem**: Some contacts have `hs_v2_date_entered_opportunity` populated but `num_associated_deals = 0`

**Cause**: Manual lifecycle stage override — someone changed the lifecycle stage by hand without associating a deal

**Solution**: Always validate SQL = `hs_v2_date_entered_opportunity` populated AND `num_associated_deals > 0`

### Revenue Mismatches

**Problem**: Revenue in analysis doesn't match HubSpot report

**Cause**: HubSpot reports may show deal pipeline amount regardless of won/lost status. Analysis should only count WON deal amounts.

**Solution**: Only sum `amount` where `hs_is_closed_won = true`. Unwon deals = $0 revenue.

### Contact Count Discrepancies

**Problem**: API returns different count than HubSpot UI report

**Common causes**:
1. **Null lead_source** (~25-30 contacts): Fixed by HAS_PROPERTY + NEQ pattern
2. **Timezone** (~25 contacts): API uses UTC, UI uses Argentina time (UTC-3). Contacts created 00:00-02:59 UTC on the 1st are in the previous month in Argentina time.
3. **Merged contacts**: Some contacts may have been merged after creation. These show up in API but not in UI reports.

**Expected margin**: After applying HAS_PROPERTY fix, expect ≤25 contact difference (timezone only). This does NOT affect SQL/deal numbers.

## Lifecycle Stage Values

HubSpot lifecycle stages in this account (in funnel order):
- `subscriber`
- `lead` ← most contacts start here
- `marketingqualifiedlead`
- `salesqualifiedlead`
- `opportunity` ← set when associated to deal (SQL)
- `customer` ← set when deal is won
- `evangelist`

The field `lifecyclestage` contains the current stage. Historical stage dates are in `hs_v2_date_entered_{stage}` fields.

## Rate Limiting

HubSpot API has rate limits:
- Search API: ~5 requests/second for paid accounts
- If you get 429 errors, add 1-2 second delays between requests
- For large analyses (3000+ contacts), expect 30-60 seconds of API time

## Account-Specific Details

- **Portal ID**: 19877595
- **Account timezone**: Argentina (UTC-3)
- **Primary pipeline**: Default pipeline
- **Deal currency**: USD (displayed as ARS-equivalent amounts)
- **Fit score field**: `fit_score_contador` (0-100 score for ICP fit)
